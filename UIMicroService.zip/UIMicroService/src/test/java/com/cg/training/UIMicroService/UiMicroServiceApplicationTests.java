package com.cg.training.UIMicroService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UiMicroServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
