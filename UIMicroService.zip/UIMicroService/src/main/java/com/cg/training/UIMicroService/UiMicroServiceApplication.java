package com.cg.training.UIMicroService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UiMicroServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(UiMicroServiceApplication.class, args);
	}

}
